<?php 
$firstName = $_POST['firstName'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

 //Database connection
 $conn = new myqli('localhost','root','test');
 if($conn->connect_error){
    die(connection Failed : '.$conn->connect_error')
 }else{
    $stmt = $conn->prepare("insert into registration('firstName','email','subject','message')
        values(?, ? ,?, ?)");
    $stmt->bind_parram("ssss", $firsstname, $emil, $subject,$message);
    $stmt->execute();
    echo "registration Successfully...";
    $stmt->close();
    $conn->close();
 }

 ?>